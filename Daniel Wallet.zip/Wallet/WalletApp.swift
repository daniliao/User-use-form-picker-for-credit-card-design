//
//  WalletApp.swift
//  Wallet
//
//  Created by Sameer Mungole on 7/28/23.
//

import SwiftUI

@main
struct WalletApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
